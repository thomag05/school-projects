//Oppgave 1
let Numbers = [];

function CountNumbers() {
  for (let i = -20; i <= 20; i++) {
    Numbers.push(i);

    if (i === -13) {
      Numbers.pop();
      continue;
    }
    if (i === 13) {
      Numbers.pop();
    } else {
      console.log(i);
    }
  }
}
CountNumbers();
let utskriftOppg1 = (document.getElementById("utskriftOppg1").innerHTML =
  Numbers);

//Oppgave 2
let alfabet = "abcdefghijklmnopqrstvuwxyzøæå";
let HALLO = alfabet[7] + alfabet[0] + alfabet[11] + alfabet[11] + alfabet[14];
let utskriftOppg2 = (document.querySelector("#utskriftOppg2").innerHTML =
  HALLO.toUpperCase());
//Oppgave 3

let knappOppg3 = document.querySelector("#btnOppg3");
knappOppg3.addEventListener("click", oppg3);
let utskriftOppg3 = document.querySelector("#utskriftOppg3");
function oppg3() {
  let name = prompt("What is your name");
  let length = name.length;
  //   console.log(
  //     "Hei, " + name + ". Så kult at navnet ditt har " + length + " bokstaver"
  //   );
  utskriftOppg3.innerHTML =
    "Hei, " + name + ". Så kult at navnet ditt har " + length + " bokstaver";
}

//Oppgave 4
let superhelter = [
  "Superman",
  "Thor",
  "Hulk",
  "Dr. Manhattan",
  "Flash",
  "Goku",
  "Silver Surfer",
  "One-Above-All",
  "Green Lantern",
  "Doctor Strange",
];
let utskriftOppg4 = document.querySelector("#utskriftOppg4");
let orderL = document.createElement("ol");
function superheroes() {
  for (let i = 0; i <= superhelter.length; i++) {
    orderL.innerHTML = superhelter[i];
    document.utskriftOppg4.appendChild(orderL);
  }
}

//Oppgave 5
